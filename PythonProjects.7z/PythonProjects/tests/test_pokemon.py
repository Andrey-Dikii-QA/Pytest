import requests
import pytest

URL = 'https://api.pokemonbattle.ru/v2'
HEADER = {'Content-Type':'application/json',
          'trainer_token':'54d94994f1a5ace017bb5368bf8ca8de'}
TRENER_ID = '7848'

def test_status_code():
    response = requests.get(url = f'{URL}/pokemons', headers = HEADER, params = {'trainer_id': TRENER_ID})
    assert response.status_code == 200