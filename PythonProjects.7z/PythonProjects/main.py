import requests
URL = 'https://api.pokemonbattle.ru/v2'
HEADER = {'Content-Type':'application/json',
          'trainer_token':'54d94994f1a5ace017bb5368bf8ca8de'}
TOKEN = '54d94994f1a5ace017bb5368bf8ca8de'
BODY_NEW_POKEMONS = {
    "name": "Абра Некодабра",
    "photo_id": 99
}
BODY_ADD_POKEBOLS = {
    "pokemon_id": "55854"
}

##1
## response_new_pokemons = requests.post(url = f'{URL}/pokemons', headers = HEADER, json = BODY_NEW_POKEMONS)
## print (response_new_pokemons.text)

##2
## response_rename_pokemons = requests.put(url = f'{URL}/pokemons', headers = HEADER, json = BODY_RENAME)
## print (response_rename_pokemons.text)

##3
response_add_pokeball = requests.post(url = f'{URL}/trainers/add_pokeball', headers = HEADER, json = BODY_ADD_POKEBOLS)
print (response_add_pokeball.text)

## 1 Создание покемона (**POST /pokemons** (*не забудь про нужный хэдер*))
## 2 Смена имени покемона (PUT /pokemons (не забудь про нужный хэдер))
## 3 Поймать покемона в покебол (POST /trainers/add_pokeball (не забудь про нужный хэдер))